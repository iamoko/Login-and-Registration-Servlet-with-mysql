/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Iamoko
 */

public class welcome extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        PrintWriter out = response.getWriter();
        //response.setHeader("Refresh","5;welcome");
        if(session!=null){
            String username = (String)session.getAttribute("username");
            out.println("<!DOCTYPE html>\n" +
"<html lang='en'>\n" +
"<head>\n" +
"	<title>Welcome</title>\n" +
"	<meta charset='UTF-8'>\n" +
"	<meta name='viewport' content='width=device-width, initial-scale=1'>	\n" +
"	<link rel='icon' type='image/png' href='style/m/images/icons/favicon.ico'/>\n" +
"	<link rel='stylesheet' type='text/css' href='style/m/vendor/bootstrap/css/bootstrap.min.css'>\n" +
"	<link rel='stylesheet' type='text/css' href='style/m/fonts/font-awesome-4.7.0/css/font-awesome.min.css'>\n" +
"	<link rel='stylesheet' type='text/css' href='style/m/vendor/animate/animate.css'>\n" +
"	<link rel='stylesheet' type='text/css' href='style/m/vendor/select2/select2.min.css'>\n" +
"	<link rel='stylesheet' type='text/css' href='style/m/vendor/perfect-scrollbar/perfect-scrollbar.css'>\n" +
"	<link rel='stylesheet' type='text/css' href='style/m/css/util.css'>\n" +
"	<link rel='stylesheet' type='text/css' href='style/m/css/main.css'>\n" +
"<!--===============================================================================================-->\n" +
"</head>\n" +
"<body>\n" +
"	\n" +
"	<div class='limiter'>\n" +
"		<div class='container-table100'>\n" +
"			<div class='wrap-table100'>\n" +
"				<div class='table100 ver1 m-b-110'>\n" +
"					<div class='table100-head'>\n" +
"						<table>\n" +
"							<thead>\n" +
"								<tr class='row100 head'>\n" +
"									<th class='cell100 column1'>Welcome</th>\n" +
"									<th class='cell100 column2'>"+username+"</th>\n" +
"								</tr>\n" +
"							</thead>\n" +
"						</table>\n" +
"					</div>\n" +
"\n" +
"					<div class='table100-body js-pscroll'>\n" +
"						<table>\n" +
"							<tbody>");
            
            try {
                Class.forName("com.mysql.jdbc.Driver");
                 Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/net_app_dev","iamoko","4826");
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM registration");
                out.println("<table>");
                
                while(rs.next()){
                    if(username.equals(rs.getString(3))){
                        out.println("<tr class='row100 body'>\n" +
"					<td class='cell100 column1'>First Name</td>\n" +
"					<td class='cell100 column2'>"+ rs.getString(1)+"</td>\n" +
"				</tr><tr class='row100 body'>\n" +
"					<td class='cell100 column1'>Last Name</td>\n" +
"					<td class='cell100 column2'>"+ rs.getString(2)+"</td>\n" +
"				</tr><tr class='row100 body'>\n" +
"					<td class='cell100 column1'>Address</td>\n" +
"					<td class='cell100 column2'>"+ rs.getString(4)+"</td>\n" +
"				</tr><tr class='row100 body'>\n" +
"					<td class='cell100 column1'>Phone Number </td>\n" +
"					<td class='cell100 column2'>"+ rs.getString(5)+"</td>\n" +
"				</tr><tr class='row100 body'>\n" +
"					<td class='cell100 column1'>Email  </td>\n" +
"					<td class='cell100 column2'>"+ rs.getString(7)+"</td>\n" +
"				</tr>");
                    }
                    
                }
                out.println("</tbody>\n" +
"				</table>\n" +
"                           </div>\n" +
"			</div>\n" +
"                        <p><a href='/NetworkApplicationDevelopment/logout'>Logout</a></p>" +
"                     </div>\n" +
"		    </div>\n" +
"	      </div>");
            } catch (Exception e) {
                out.println(e);
            }
           
        }else{
            out.println("<h3>Login Please</h3>");
            request.getRequestDispatcher("login.html").include(request, response);
        }
        out.println("<script src='style/m/vendor/jquery/jquery-3.2.1.min.js'></script>\n" +
"	<script src='style/m/vendor/bootstrap/js/popper.js'></script>\n" +
"	<script src='style/m/vendor/bootstrap/js/bootstrap.min.js'></script>\n" +
"	<script src='style/m/vendor/select2/select2.min.js'></script>\n" +
"	<script src='style/m/vendor/perfect-scrollbar/perfect-scrollbar.min.js'></script>\n" +
"	<script>\n" +
"		$('.js-pscroll').each(function(){\n" +
"			var ps = new PerfectScrollbar(this);\n" +
"\n" +
"			$(window).on('resize', function(){\n" +
"				ps.update();\n" +
"			})\n" +
"		});\n" +
"			\n" +
"		\n" +
"	</script>\n" +
"	<script src='style/m/js/main.js'></script>\n" +
"\n" +
"</body>\n" +
"</html>");
        out.close();
    } 
}
