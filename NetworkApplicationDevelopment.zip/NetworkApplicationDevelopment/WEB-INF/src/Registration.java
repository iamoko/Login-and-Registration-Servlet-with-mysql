import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
import java.io.IOException;


/**
 *
 * @author Iamoko
 */
class AES {
    /**
     * @param args the command line arguments
     */
    private static final String ALGO = "AES";
    private static final byte[] keyValue =
            new byte[]{'T', 'h', 'e', 'B', 'e', 's', 't', 'S', 'e', 'c', 'r', 'e', 't', 'K', 'e', 'y'};

    /**
     * Encrypt a string with AES algorithm.
     *
     * @param data is a string
     * @return the encrypted string
     */
    public static String encrypt(String data) throws Exception {
        Key key = generateKey();
        Cipher c = Cipher.getInstance(ALGO);
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] encVal = c.doFinal(data.getBytes());
        return Base64.getEncoder().encodeToString(encVal);
    }

    /**
     * Decrypt a string with AES algorithm.
     *
     * @param encryptedData is a string
     * @return the decrypted string
     */
    public static String decrypt(String encryptedData) throws Exception {
        Key key = generateKey();
        Cipher c = Cipher.getInstance(ALGO);
        c.init(Cipher.DECRYPT_MODE, key);
        byte[] decordedValue = Base64.getDecoder().decode(encryptedData);
        byte[] decValue = c.doFinal(decordedValue);
        return new String(decValue);
    }

    /**
     * Generate a new encryption key.
     */
    private static Key generateKey() throws Exception {
        return new SecretKeySpec(keyValue, ALGO);
    }
}

public class Registration extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out =response.getWriter();
        response.setContentType("text/html");
        //getting the parameters from html file
        String fname = request.getParameter("fname");
        String lname = request.getParameter("lname");
        String username = request.getParameter("username");
        String address = request.getParameter("address");
        String number = request.getParameter("number");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        AES obj = new AES();
        String pw;
        try{
            pw = obj.encrypt(password);
            //creating the databse Connecion
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/net_app_dev","iamoko","4826");
            Statement st = con.createStatement();
            
            ResultSet rs = st.executeQuery("SELECT * FROM registration");
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            Boolean exist = false;
            while(rs.next()){
                if(username.equals(rs.getString(3))){
                    exist = true;   
                }
            }
            if(exist == true){
                out.println("<title>Username exists</title>");            
                out.println("</head>");
                out.println("<body>");
                out.println("<h2>Username exists</h2>");
                request.getRequestDispatcher("index.html").include(request, response);
            }else{
                out.println("<title>Registration</title>");            
                out.println("</head>");
                out.println("<body>");
                int i = st.executeUpdate("INSERT INTO `registration` VALUES ('"+fname+"','"+lname+"','"+username+"','"+address+"','"+number+"','"+pw+"','"+email+"')");
                if(i>0){
                    out.println("<h3>You have been successfully registered</h3>"); 
                    request.getRequestDispatcher("login.html").include(request, response);
                }else{
                    out.println("Registration Failed");
                }
            }
            out.println("</body>");
            out.println("</html>");
            out.close();
            con.close();
        }catch(Exception e){
            out.println(e);
        }
        
    }
}
